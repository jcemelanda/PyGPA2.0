rm -rf /usr/bin/pygpa
