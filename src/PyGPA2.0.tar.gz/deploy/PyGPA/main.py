from control.control_main import Main_Ctrl

Main_Ctrl()