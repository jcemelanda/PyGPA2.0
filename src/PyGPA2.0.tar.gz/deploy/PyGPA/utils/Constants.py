# -*- coding: utf-8 -*-
nomes_dos_campos = {
                    0:'Aleatório',
                    1:'Constante',
                    2:'Doublet',
                    3:'Fonte/Sumidouro',
                    4:'Turbilhão',
                    5:'Combinado'
                    }