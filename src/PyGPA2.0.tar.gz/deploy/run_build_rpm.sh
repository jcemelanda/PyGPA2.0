python setup.py bdist_rpm --post-install=post_install.sh --post-uninstall=post_uninstall.sh
