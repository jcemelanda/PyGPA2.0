# -*- coding: utf-8 -*-
from PyQt4 import QtCore, QtGui
from control.control_set_creator import Set_Creator_Ctrl
from control.control_analisys import Analise_Ctrl
from models.campos import campo_combinado
from utils.Constants import nomes_dos_campos
from view.view_generator import Generator_View


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Generator_Ctrl:
    def __init__(self):
        self.pilha = []
        self.ui = Generator_View(self)
        self.ui.showMaximized()
        self.status = "" 

    def gerar_novo_campo(self):
        self.ctrl_set_creator = Set_Creator_Ctrl(self)
        self.status = 'novo'
        
    def recebe_campo(self, campo):
        if self.status == 'novo':
            self.add_novo_campo(campo)
        else:
            self.atualiza_campo(campo)
        self.ctrl_set_creator.close_window()
        del(self.ctrl_set_creator)
        
    def atualizar_campo(self):
        if len(self.pilha) > 0:
            i = self.ui.getListWidget().currentRow()
            if i < 0:
                message = QtGui.QMessageBox(self.ui)
                message.setText('Selecione um elemento da lista para editar')
                message.show()
                pass
            else:
                campo = self.pilha[self.ui.getListWidget().currentRow()]
                print campo
                self.ctrl_set_creator = Set_Creator_Ctrl(self, campo)
                self.status = 'edita'
        else:
            message = QtGui.QMessageBox(self.ui)
            message.setText('Para inserir um campo, clique em Novo')
            message.show()
            pass
        
    def atualiza_campo(self, campo):
        i = self.ui.getListWidget().currentRow()
        self.pilha[i] = campo
        self.ui.getListWidget().takeItem(i)
        self.ui.getListWidget().insertItem(i, QtGui.QListWidgetItem(_fromUtf8(nomes_dos_campos[campo.get_type()])))
        
    def add_novo_campo(self, campo):
        self.pilha.insert(0, campo)
        self.ui.getListWidget().insertItem(0, QtGui.QListWidgetItem(_fromUtf8(nomes_dos_campos[campo.get_type()])))
        
    def combina_campos(self):
        mat = []
        for campo in self.pilha:
            mat.append(campo.get_mat())
        m1 = zip(*mat)
        print m1
        m2 = [zip(*m1[i]) for i in range(len(m1))]
        print m2
        super_mat = []
        for matriz in m2:
            m = []
            for linha in matriz:
                novaLinha = zip(*linha)
                l = []
                for elemento in novaLinha:
                    l.append(tuple(map(sum, zip(*elemento))))
                m.append(l)
            super_mat.append(m)
            
        combinado = campo_combinado(len(super_mat), 
                                    len(super_mat[0]), 
                                    len(super_mat[0][0]), 
                                    super_mat[:], 
                                    self.pilha[:])
        self.pilha = []
        self.ui.getListWidget().clear()
        self.add_novo_campo(combinado)
        
        
    def remove_item(self):
        i = self.ui.getListWidget().currentRow()
        self.pilha.pop(i)
        self.ui.getListWidget().takeItem(i)
        
    def limpa_lista(self):
        self.pilha = []
        self.ui.getListWidget().clear()
        
    def analisar(self):
        super_mat = (self.pilha[self.ui.getListWidget().currentRow()]).get_mat()
        c = Analise_Ctrl(super_mat)
        c.processa_matrizes()
 
